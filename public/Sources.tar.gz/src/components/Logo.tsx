import React from 'react'
const Logo = (props: any) => {
  return <img alt="Logo" src="/static/logo.svg" {...props} height="60" />
}

export default Logo
